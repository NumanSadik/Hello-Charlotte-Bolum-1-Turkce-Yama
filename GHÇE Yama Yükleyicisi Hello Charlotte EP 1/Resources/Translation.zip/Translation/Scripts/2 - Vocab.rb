#==============================================================================
# ** Vocab - Bu oyun Game Hunters Çeviri Ekibi tarafından Türkçeye çevrilmiştir. İletişim için: gamehuntersceviri@gmail.com
#------------------------------------------------------------------------------
#  This module defines terms and messages. It defines some data as constant
# variables. Terms in the database are obtained from $data_system.
#==============================================================================

module Vocab

  # Shop Screen
  ShopBuy         = "Satın Al"
  ShopSell        = "Sat"
  ShopCancel      = "Vazgeç"
  Possession      = "Sahip Olduğun"

  # Status Screen
  ExpTotal        = "Mevcut Deneyim"
  ExpNext         = "Sonrakine %s"

  # Save/Load Screen
  SaveMessage     = "Hangi dosyaya kaydedilsin?"
  LoadMessage     = "Hangi dosya yüklensin?"
  File            = "Dosya"

  # Display when there are multiple members
  PartyName       = "%s''ın Takımı"

  # Basic Battle Messages
  Emerge          = "%s belirdi!"
  Preemptive      = "%s, üstünlüğü ele geçirdi!"
  Surprise        = "%s şaşırdı!"
  EscapeStart     = "%s kaçmaya başladı!"
  EscapeFailure   = "Ancak kaçmayı başaramadı!"

  # Battle Ending Messages
  Victory         = "%s kazandı!"
  Defeat          = "%s yenildi."
  ObtainExp       = "%s Deneyim elde edildi!"
  ObtainGold      = "%s\\G buldun!"
  ObtainItem      = "%s buldun!"
  LevelUp         = "%s şimdi %s %s!"
  ObtainSkill     = "%s öğrendi!"

  # Use Item
  UseItem         = "%s kullanıyor %s!"

  # Critical Hit
  CriticalToEnemy = "İnanılmaz bir vuruş!!"
  CriticalToActor = "Acı veren bir patak!!"

  # Results for Actions on Actors
  ActorDamage     = "%s %s hasar aldı!"
  ActorRecovery   = "%s yenilendi %s %s!"
  ActorGain       = "%s elde etti %s %s!"
  ActorLoss       = "%s kaybetti %s %s!"
  ActorDrain      = "%s, %s %s kaybetti!"
  ActorNoDamage   = "%s hiç hasar almadı!"
  ActorNoHit      = "Iska! %s hiç hasar almadı!"

  # Results for Actions on Enemies
  EnemyDamage     = "%s %s hasar aldı!"
  EnemyRecovery   = "%s yenilendi %s %s!"
  EnemyGain       = "%s kazandı %s %s!"
  EnemyLoss       = "%s kaybetti %s %s!"
  EnemyDrain      = "%s, %s %s kaybetti!"
  EnemyNoDamage   = "%s hiç hasar almadı!"
  EnemyNoHit      = "Iskaladı! %s hiç hasar almadı!"

  # Evasion/Reflection
  Evasion         = "%s saldırıdan kaçındı!"
  MagicEvasion    = "%s büyüyü etkisizleştirdi!"
  MagicReflection = "%s büyüyü yansıttı!"
  CounterAttack   = "%s karşıladı!"
  Substitute      = "%s korudu %s!"

  # Buff/Debuff
  BuffAdd         = "%s'ın %s'ı yükseldi!"
  DebuffAdd       = "%s'ın %s'ı düştü!"
  BuffRemove      = "%s'ın %s'ı normale döndü."

  # Skill or Item Had No Effect
  ActionFailure   = "%s'a hiç etkisi olmadı!"

  # Error Message
  PlayerPosError  = "Oyuncunun başlangıç noktası ayarlanmamış."
  EventOverflow   = "Yaygın etkinlik çağrıları sınırı geçmiş."

  # Basic Status
  def self.basic(basic_id)
    $data_system.terms.basic[basic_id]
  end

  # Parameters
  def self.param(param_id)
    $data_system.terms.params[param_id]
  end

  # Equip Type
  def self.etype(etype_id)
    $data_system.terms.etypes[etype_id]
  end

  # Commands
  def self.command(command_id)
    $data_system.terms.commands[command_id]
  end

  # Currency Unit
  def self.currency_unit
    $data_system.currency_unit
  end

  #--------------------------------------------------------------------------
  def self.level;       basic(0);     end   # Level
  def self.level_a;     basic(1);     end   # Level (short)
  def self.hp;          basic(2);     end   # HP
  def self.hp_a;        basic(3);     end   # HP (short)
  def self.mp;          basic(4);     end   # MP
  def self.mp_a;        basic(5);     end   # MP (short)
  def self.tp;          basic(6);     end   # TP
  def self.tp_a;        basic(7);     end   # TP (short)
  def self.fight;       command(0);   end   # Fight
  def self.escape;      command(1);   end   # Escape
  def self.attack;      command(2);   end   # Attack
  def self.guard;       command(3);   end   # Guard
  def self.item;        command(4);   end   # Items
  def self.skill;       command(5);   end   # Skills
  def self.equip;       command(6);   end   # Equip
  def self.status;      command(7);   end   # Status
  def self.formation;   command(8);   end   # Change Formation
  def self.save;        command(9);   end   # Save
  def self.game_end;    command(10);  end   # Exit Game
  def self.weapon;      command(12);  end   # Weapons
  def self.armor;       command(13);  end   # Armor
  def self.key_item;    command(14);  end   # Key Items
  def self.equip2;      command(15);  end   # Change Equipment
  def self.optimize;    command(16);  end   # Ultimate Equipment
  def self.clear;       command(17);  end   # Remove All
  def self.new_game;    command(18);  end   # New Game
  def self.continue;    command(19);  end   # Continue
  def self.shutdown;    command(20);  end   # Shut Down
  def self.to_title;    command(21);  end   # Go to Title
  def self.cancel;      command(22);  end   # Cancel
  #--------------------------------------------------------------------------
end
