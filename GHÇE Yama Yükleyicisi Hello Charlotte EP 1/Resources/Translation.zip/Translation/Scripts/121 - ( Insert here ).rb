=begin


* To users of scripts

 * When using scripts obtained through online websites,
  create a new section at this position and paste the script here.
  (Select "Insert" from the pop-up menu in the left list box.)

 * If the creator of the script has any other special instructions, follow them.

 * In general, RPG Maker VX and RPG Maker XP scripts are not compatible, 
   so make sure the resources you have are for RPG Maker VX Ace 
   before you use them.


* To authors of scripts

 * When developing scripts to be distributed to the general public,
  we recommend that you use redefinitions and aliases as much as
  possible, to allow the script to run just by pasting it in this position.


=end
