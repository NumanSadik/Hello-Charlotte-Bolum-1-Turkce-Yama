#==============================================================================
# ** Main
#------------------------------------------------------------------------------
#  This processing is executed after module and class definition is finished.
#==============================================================================
Font.default_name = ["Coder's Crux"]
  Font.default_size = 17
  Font.default_outline = false
  Font.default_bold = false
  Font.default_italic = false
  Font.default_shadow = false
  
rgss_main { SceneManager.run }
